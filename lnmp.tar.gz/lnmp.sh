#!/bin/bash

dir=/usr/local/src/lnmp
cd $dir
tar zxvf lnmp.tar.gz
cd $dir
sh mysql_install.sh
cd $dir
sh php_install.sh
cd $dir
sh nginx_install.sh
cd $dir
sh nginx_start.sh

#rm -rf /usr/local/nginx/conf/nginx.conf
/bin/cp $dir/nginx.conf  /usr/local/nginx/conf/

mkdir /usr/local/nginx/conf/vhosts
/bin/cp $dir/111.conf  /usr/local/nginx/conf/vhosts/
/usr/local/nginx/sbin/nginx -t
/etc/init.d/nginx reload

/bin/cp $dir//php-fpm.conf /usr/local/php/etc/
/usr/local/php/sbin/php-fpm -t
/etc/init.d/php-fpm restart

echo "LNMP complete!!!"
